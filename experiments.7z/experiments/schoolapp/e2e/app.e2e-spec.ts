import { SchoolappPage } from './app.po';

describe('schoolapp App', () => {
  let page: SchoolappPage;

  beforeEach(() => {
    page = new SchoolappPage();
  });

  it('should display welcome message', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('Welcome to app!!');
  });
});
