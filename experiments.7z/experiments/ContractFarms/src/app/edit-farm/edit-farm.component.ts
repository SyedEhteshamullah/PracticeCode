import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators} from '@angular/forms';

@Component({
  selector: 'app-edit-farm',
  templateUrl: './edit-farm.component.html',
  styleUrls: ['./edit-farm.component.css']
})
export class EditFarmComponent implements OnInit {

  editFarm: FormGroup;
  farmOwner:any;
  firstName: string;
  middleName: string;
  lastName: string;
  doB: Date;
  gender: string;
  panNumber: string;
  aadharNumber: string;
  addressLine1: string;
  addressLine2: string;
  city: string;
  state: string;
  pincode: string;
  firstNameAlert: string = "This field is required!";

  constructor( private fb: FormBuilder) { 

    this.editFarm = fb.group({
      'firstName':[null,Validators.compose([Validators.required,Validators.minLength(2),Validators.maxLength(40)])],
      'middleName':[null,Validators.compose([Validators.minLength(3),Validators.maxLength(40)])],
      'lastName':[null,Validators.compose([Validators.required,Validators.minLength(2),Validators.maxLength(40)])],
      'doB':[null,Validators.compose([Validators.required,Validators.max((new Date()).setFullYear(new Date().getFullYear()-19))])],
      'gender':[null,Validators.required],
      'panNumber':[null,Validators.required],
      'aadharNumber':[null,Validators.required],
      'addressLine1':[null,Validators.required],
      'addressLine2':[null,Validators.required],
      'city':[null,Validators.required],
      'state':[null,Validators.required],
      'pincode':[null,Validators.required]
    });
  }
  //genders = [{value:"male",viewValue:"Male"},{value:"female",viewValue:"Female"}];
  genders = ["Male","Female"];
  selectedGender: string;

  myFilter = (d: Date): boolean => {
    const day = d.getDay();
    let now = new Date();
    now.setFullYear(now.getFullYear() - 19);
    
  
    // Prevent Saturday and Sunday from being selected.
    return d > now;
  }

  addFarmOwner(farmOwner){
    this.firstName = farmOwner.firstName;
    this.middleName = farmOwner.middleName;
    this.lastName = farmOwner.lastName;
    this.doB = farmOwner.doB;
    this.gender = farmOwner.gender;
    this.panNumber = farmOwner.panNumber;
    this.aadharNumber = farmOwner.aadharNumber;
    this.addressLine1 = farmOwner.addressLine1;
    this.addressLine2 = farmOwner.addressLine2;
    this.city = farmOwner.city;
    this.state = farmOwner.state;
    this.pincode = farmOwner.pincode;
  }

  ngOnInit() {
  }

}
