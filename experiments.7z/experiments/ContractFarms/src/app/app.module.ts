import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MdInputModule, MdRadioModule, MdSlideToggleModule } from '@angular/material';
import { MdDatepickerModule, MdCheckboxModule, MdSelectModule } from '@angular/material';
import { MdMenuModule, MdSidenavModule, MdToolbarModule } from '@angular/material';
import { MdListModule, MdGridListModule, MdCardModule } from '@angular/material';
import { MdTabsModule, MdButtonModule, MdButtonToggleModule } from '@angular/material';
import { MdChipsModule, MdIconModule, MdProgressSpinnerModule } from '@angular/material';
import { MdProgressBarModule, MdDialogModule, MdTooltipModule, MdSnackBarModule } from '@angular/material';
import { MdNativeDateModule } from '@angular/material';

import { AppComponent } from './app.component';
import { EditFarmComponent } from './edit-farm/edit-farm.component';
import { TestComponent } from './test/test.component';
import { LandingComponent } from './landing/landing.component';
import { CardTestComponent } from './card-test/card-test.component';

@NgModule({
  declarations: [
    AppComponent,
    EditFarmComponent,
    TestComponent,
    LandingComponent,
    CardTestComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    FormsModule,
    ReactiveFormsModule,
    HttpModule,
    MdGridListModule,
    MdInputModule,
    MdCardModule,
    MdButtonModule,
    MdSelectModule,
    MdDatepickerModule,
    MdNativeDateModule,
    MdTabsModule,
    MdListModule,
    MdCardModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
