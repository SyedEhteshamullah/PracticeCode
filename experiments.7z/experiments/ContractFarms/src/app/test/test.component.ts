import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-test',
  templateUrl: './test.component.html',
  styleUrls: ['./test.component.css']
})
export class TestComponent implements OnInit {

  addFarm: FormGroup;
  farmName: string;
  registrationNumber : string;
  addressLine1: string;
  addressLine2: string;
  cityDistrict: string;
  state: string
  farmList : Array<any>;


  constructor(private fb: FormBuilder) { 
    this.addFarm = fb.group({
      'farmName':[null,Validators.compose([Validators.required,Validators.minLength(2),Validators.maxLength(40)])],
      'registrationNumber':[null,Validators.compose([Validators.required,Validators.minLength(2),Validators.maxLength(40)])],
      'addressLine1':[null,Validators.compose([Validators.required,Validators.minLength(2),Validators.maxLength(40)])],
      'addressLine2':[null,Validators.compose([Validators.required,Validators.minLength(2),Validators.maxLength(40)])],
      'cityDistrict':[null,Validators.compose([Validators.required,Validators.minLength(2),Validators.maxLength(40)])],
      'state':[null,Validators.compose([Validators.required,Validators.minLength(2),Validators.maxLength(40)])]
    });
    this.farmList = [];
  }

  addToFarmList(addFarm) {

    let farmObj = {
      "farmName": addFarm.farmName,
      "registrationNumber":addFarm.registrationNumber,
      "addressLine1":addFarm.addressLine1,
      "addressLine2":addFarm.addressLine2,
      "cityDistrict":addFarm.cityDistrict,
      "state":addFarm.state
    }
    
    this.farmList.push(farmObj);
  }

  ngOnInit() {
  }


}
