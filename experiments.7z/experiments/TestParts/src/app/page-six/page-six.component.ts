import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-page-six',
  templateUrl: './page-six.component.html',
  styleUrls: ['./page-six.component.css']
})
export class PageSixComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
