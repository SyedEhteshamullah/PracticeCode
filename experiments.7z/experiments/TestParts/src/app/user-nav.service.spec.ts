import { TestBed, inject } from '@angular/core/testing';

import { UserNavService } from './user-nav.service';

describe('UserNavService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [UserNavService]
    });
  });

  it('should be created', inject([UserNavService], (service: UserNavService) => {
    expect(service).toBeTruthy();
  }));
});
