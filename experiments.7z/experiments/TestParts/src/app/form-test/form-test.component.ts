import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-form-test',
  templateUrl: './form-test.component.html',
  styleUrls: ['./form-test.component.css']
})
export class FormTestComponent implements OnInit {

  areaUnits = [
    {value: 'sqmeters', viewValue: 'Square Meters'},
    {value: 'sqfeets', viewValue: 'Square Feets'},
    {value: 'hectares', viewValue: 'Hectares'}
  ];

  constructor() { }

  ngOnInit() {
  }

}
