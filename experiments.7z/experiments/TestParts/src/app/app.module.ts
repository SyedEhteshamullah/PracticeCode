import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';
import { HttpModule } from '@angular/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MdInputModule, MdRadioModule, MdSlideToggleModule } from '@angular/material';
import { MdDatepickerModule, MdCheckboxModule, MdSelectModule } from '@angular/material';
import { MdMenuModule, MdSidenavModule, MdToolbarModule } from '@angular/material';
import { MdListModule, MdGridListModule, MdCardModule } from '@angular/material';
import { MdTabsModule, MdButtonModule, MdButtonToggleModule } from '@angular/material';
import { MdChipsModule, MdIconModule, MdProgressSpinnerModule } from '@angular/material';
import { MdProgressBarModule, MdDialogModule, MdTooltipModule, MdSnackBarModule } from '@angular/material';
import { MdNativeDateModule, MdAutocompleteModule } from '@angular/material';
import { MdTableModule,MdPaginator, MdSortModule } from '@angular/material';
import { CdkTableModule } from '@angular/cdk'


import { AppComponent } from './app.component';
import { EditFarmComponent } from './edit-farm/edit-farm.component';
import { TestComponent } from './test/test.component';
import { LandingComponent } from './landing/landing.component';
import { FormTestComponent } from './form-test/form-test.component';
import { CardTestComponent } from './card-test/card-test.component';
import { PageOneComponent } from './page-one/page-one.component';
import { PageTwoComponent } from './page-two/page-two.component';
import { PageThreeComponent } from './page-three/page-three.component';
import { PageFourComponent } from './page-four/page-four.component';
import { PageFiveComponent } from './page-five/page-five.component';
import { PageSixComponent } from './page-six/page-six.component';
import { PageSevenComponent } from './page-seven/page-seven.component';
import { PageEightComponent } from './page-eight/page-eight.component';
import { PageNineComponent } from './page-nine/page-nine.component';
import { PageTenComponent } from './page-ten/page-ten.component';

@NgModule({
  declarations: [
    AppComponent,
    EditFarmComponent,
    TestComponent,
    LandingComponent,
    FormTestComponent,
    CardTestComponent,
    PageOneComponent,
    PageTwoComponent,
    PageThreeComponent,
    PageFourComponent,
    PageFiveComponent,
    PageSixComponent,
    PageSevenComponent,
    PageEightComponent,
    PageNineComponent,
    PageTenComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    FormsModule,
    ReactiveFormsModule,
    HttpModule,
    MdGridListModule,
    MdInputModule,
    MdCardModule,
    MdButtonModule,
    MdSelectModule,
    MdDatepickerModule,
    MdNativeDateModule,
    MdTabsModule,
    MdListModule,
    MdCardModule,
    MdSidenavModule,
    MdToolbarModule,
    MdIconModule,
    MdMenuModule,
    MdCheckboxModule,
    MdAutocompleteModule,
    MdTableModule,
    CdkTableModule,
    MdSortModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
