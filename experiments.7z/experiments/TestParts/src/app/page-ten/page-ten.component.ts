import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-page-ten',
  templateUrl: './page-ten.component.html',
  styleUrls: ['./page-ten.component.css']
})
export class PageTenComponent implements OnInit {

  salutations = ['Mr','Mrs','Dr'];
  salutation :string = 'Mr';
  showVal(){
    console.log(this.salutation);
  }

  constructor() { }

  ngOnInit() {
  }

}
