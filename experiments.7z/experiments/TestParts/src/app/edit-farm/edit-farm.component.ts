import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators} from '@angular/forms';

@Component({
  selector: 'app-edit-farm',
  templateUrl: './edit-farm.component.html',
  styleUrls: ['./edit-farm.component.css']
})
export class EditFarmComponent implements OnInit {

  farmDetails : Object;
  farmList: Array<Object>;

  constructor( private fb: FormBuilder) { 

    this.farmList=[{
      "farmName":"First Farm",
      "registrationNumber":"First Farm Reg 1",
      "landRecordNumber":"First Farm Land Record Number 1",
      "farmAddress1":"First Farm address 1",
      "farmAddress2":"First Farm Address 2",
      "cityDistrict":"First District",
      "state":"Telangana",
      "farmArea":3.5,
      "farmAreaUnits":"acres",
      "amenities":["Borewell","GreenHouseShed","StorageRoom","Tractor"],
      "farmSoilType":"Red Soil",
    }];

    
  }

  
  

  ngOnInit() {
  }

}
