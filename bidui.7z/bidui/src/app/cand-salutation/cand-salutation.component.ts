import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cand-salutation',
  templateUrl: './cand-salutation.component.html',
  styleUrls: ['./cand-salutation.component.css']
})
export class CandSalutationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
