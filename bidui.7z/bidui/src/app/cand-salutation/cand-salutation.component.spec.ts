import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CandSalutationComponent } from './cand-salutation.component';

describe('CandSalutationComponent', () => {
  let component: CandSalutationComponent;
  let fixture: ComponentFixture<CandSalutationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CandSalutationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CandSalutationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
