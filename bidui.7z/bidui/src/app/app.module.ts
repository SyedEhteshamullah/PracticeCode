import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';
import { HttpModule } from '@angular/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';


import { AppComponent } from './app.component';
import { NavrfxComponent } from './navrfx/navrfx.component';
import { RequestLandingComponent } from './request-landing/request-landing.component';
import { CandBasicDetailsComponent } from './cand-basic-details/cand-basic-details.component';
import { CandSalutationComponent } from './cand-salutation/cand-salutation.component';
import { CandAddressContactComponent } from './cand-address-contact/cand-address-contact.component';
import { CandSkillsComponent } from './cand-skills/cand-skills.component';
import { Score5Component } from './score5/score5.component';
import { Score10Component } from './score10/score10.component';
import { CandProjectsComponent } from './cand-projects/cand-projects.component';
import { CandExpComponent } from './cand-exp/cand-exp.component';
import { CandCertComponent } from './cand-cert/cand-cert.component';
import { CandAwardsComponent } from './cand-awards/cand-awards.component';
import { CandPubComponent } from './cand-pub/cand-pub.component';
import { CandLinksComponent } from './cand-links/cand-links.component';
import { CandProfileComponent } from './cand-profile/cand-profile.component';

@NgModule({
  declarations: [
    AppComponent,
    NavrfxComponent,
    RequestLandingComponent,
    CandBasicDetailsComponent,
    CandSalutationComponent,
    CandAddressContactComponent,
    CandSkillsComponent,
    Score5Component,
    Score10Component,
    CandProjectsComponent,
    CandExpComponent,
    CandCertComponent,
    CandAwardsComponent,
    CandPubComponent,
    CandLinksComponent,
    CandProfileComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    FormsModule,
    ReactiveFormsModule,
    HttpModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
