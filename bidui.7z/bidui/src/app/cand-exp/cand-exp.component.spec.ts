import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CandExpComponent } from './cand-exp.component';

describe('CandExpComponent', () => {
  let component: CandExpComponent;
  let fixture: ComponentFixture<CandExpComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CandExpComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CandExpComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
