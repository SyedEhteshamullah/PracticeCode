import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cand-exp',
  templateUrl: './cand-exp.component.html',
  styleUrls: ['./cand-exp.component.css']
})
export class CandExpComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
