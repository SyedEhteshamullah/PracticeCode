import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-score5',
  templateUrl: './score5.component.html',
  styleUrls: ['./score5.component.css']
})
export class Score5Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
