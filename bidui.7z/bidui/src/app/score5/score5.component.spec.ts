import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Score5Component } from './score5.component';

describe('Score5Component', () => {
  let component: Score5Component;
  let fixture: ComponentFixture<Score5Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Score5Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Score5Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
