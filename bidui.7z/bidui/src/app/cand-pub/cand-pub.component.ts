import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cand-pub',
  templateUrl: './cand-pub.component.html',
  styleUrls: ['./cand-pub.component.css']
})
export class CandPubComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
