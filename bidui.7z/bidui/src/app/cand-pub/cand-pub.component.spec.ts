import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CandPubComponent } from './cand-pub.component';

describe('CandPubComponent', () => {
  let component: CandPubComponent;
  let fixture: ComponentFixture<CandPubComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CandPubComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CandPubComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
