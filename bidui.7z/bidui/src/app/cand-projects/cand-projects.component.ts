import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cand-projects',
  templateUrl: './cand-projects.component.html',
  styleUrls: ['./cand-projects.component.css']
})
export class CandProjectsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
