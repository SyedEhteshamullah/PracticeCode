import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CandProjectsComponent } from './cand-projects.component';

describe('CandProjectsComponent', () => {
  let component: CandProjectsComponent;
  let fixture: ComponentFixture<CandProjectsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CandProjectsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CandProjectsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
