import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cand-profile',
  templateUrl: './cand-profile.component.html',
  styleUrls: ['./cand-profile.component.css']
})
export class CandProfileComponent implements OnInit {

  salutations = ['Mr.','Mrs.','Ms.','Dr.','Prof.'];

  salutation: string = 'Ms.';
  firstName: string;
  lastName: string;
  middleName: string;
  pancard: string;
  passport: string;
  gender: string;
  maritalStatus: string;

  changeSalutation(sal:string){
    console.log('triggered');
    //this.salutation = sal;
  }

  updateProfile(){
    console.log(this.salutation);
    console.log(this.firstName);
  }

  constructor() { }

  ngOnInit() {
  }

}
