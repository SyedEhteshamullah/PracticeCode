import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cand-awards',
  templateUrl: './cand-awards.component.html',
  styleUrls: ['./cand-awards.component.css']
})
export class CandAwardsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
