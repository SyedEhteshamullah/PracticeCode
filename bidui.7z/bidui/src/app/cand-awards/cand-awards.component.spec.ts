import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CandAwardsComponent } from './cand-awards.component';

describe('CandAwardsComponent', () => {
  let component: CandAwardsComponent;
  let fixture: ComponentFixture<CandAwardsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CandAwardsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CandAwardsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
