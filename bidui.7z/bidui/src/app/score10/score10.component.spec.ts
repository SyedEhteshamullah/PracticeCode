import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Score10Component } from './score10.component';

describe('Score10Component', () => {
  let component: Score10Component;
  let fixture: ComponentFixture<Score10Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Score10Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Score10Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
