import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-score10',
  templateUrl: './score10.component.html',
  styleUrls: ['./score10.component.css']
})
export class Score10Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
