import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cand-address-contact',
  templateUrl: './cand-address-contact.component.html',
  styleUrls: ['./cand-address-contact.component.css']
})
export class CandAddressContactComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
