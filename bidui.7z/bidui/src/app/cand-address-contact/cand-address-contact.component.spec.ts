import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CandAddressContactComponent } from './cand-address-contact.component';

describe('CandAddressContactComponent', () => {
  let component: CandAddressContactComponent;
  let fixture: ComponentFixture<CandAddressContactComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CandAddressContactComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CandAddressContactComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
