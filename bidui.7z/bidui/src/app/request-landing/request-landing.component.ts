import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-request-landing',
  templateUrl: './request-landing.component.html',
  styleUrls: ['./request-landing.component.css']
})
export class RequestLandingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
