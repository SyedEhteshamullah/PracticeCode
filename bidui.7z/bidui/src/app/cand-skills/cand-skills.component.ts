import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cand-skills',
  templateUrl: './cand-skills.component.html',
  styleUrls: ['./cand-skills.component.css']
})
export class CandSkillsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
