export class ProfileModel {
    constructor(
        public salutation: string,
        public firstName: string,
        public middleName: string,
        public lastName: string
    ){}
}
