import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NavrfxComponent } from './navrfx.component';

describe('NavrfxComponent', () => {
  let component: NavrfxComponent;
  let fixture: ComponentFixture<NavrfxComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NavrfxComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NavrfxComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
