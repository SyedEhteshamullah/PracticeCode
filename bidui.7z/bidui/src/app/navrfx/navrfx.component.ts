import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-navrfx',
  templateUrl: './navrfx.component.html',
  styleUrls: ['./navrfx.component.css']
})
export class NavrfxComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
