import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CandLinksComponent } from './cand-links.component';

describe('CandLinksComponent', () => {
  let component: CandLinksComponent;
  let fixture: ComponentFixture<CandLinksComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CandLinksComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CandLinksComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
