import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cand-links',
  templateUrl: './cand-links.component.html',
  styleUrls: ['./cand-links.component.css']
})
export class CandLinksComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
