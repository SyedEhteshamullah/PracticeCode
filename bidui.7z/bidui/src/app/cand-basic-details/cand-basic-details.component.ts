import { Component, OnInit,Input } from '@angular/core';

@Component({
  selector: 'app-cand-basic-details',
  templateUrl: './cand-basic-details.component.html',
  styleUrls: ['./cand-basic-details.component.css']
})
export class CandBasicDetailsComponent implements OnInit {
  
  firstName:string;
  middleName:string;
  lastName:string;
  salutation:string;
  pancard:string;
  passport:string;
  gender:string;
  maritalstatus:string; 

  constructor() { 
  }

  ngOnInit() {
  }

}
