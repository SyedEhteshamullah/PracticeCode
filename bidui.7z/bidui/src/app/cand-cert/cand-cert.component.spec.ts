import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CandCertComponent } from './cand-cert.component';

describe('CandCertComponent', () => {
  let component: CandCertComponent;
  let fixture: ComponentFixture<CandCertComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CandCertComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CandCertComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
