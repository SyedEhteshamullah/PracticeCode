import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cand-cert',
  templateUrl: './cand-cert.component.html',
  styleUrls: ['./cand-cert.component.css']
})
export class CandCertComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
